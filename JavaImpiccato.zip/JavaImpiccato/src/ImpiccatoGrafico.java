
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author 19989
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.imageio.ImageIO;

public class ImpiccatoGrafico extends JFrame implements ActionListener {

    //variabili grafica:
    private JButton[] letterButtons; // Array di bottoni per le lettere dell'alfabeto
    private JLabel l1, l2, l3, l4, l5; // Etichette per visualizzare informazioni di gioco
    private JPanel mainPanel, p1, p2, p3, p4, p5, p6; // Pannelli per organizzare gli elementi
    private JTextField t1; // Campo di testo per inserire una parola per intero

    //variabili per il funzionamento del gioco:
    private String parolaSegreta; // Parola segreta da indovinare
    private char[] parolaNascosta; // Array per la visualizzazione della parola con le lettere nascoste
    private int tentativiRimanenti; // Numero di tentativi rimanenti
    private int vittorie; // Numero di vittorie
    private int sconfitte; // Numero di sconfitte

    public ImpiccatoGrafico(String titolo) {
        super(titolo); // "titolo" della finestra di gioco
        setLayout(null); // layout su null per controllo preciso delle posizioni
        setSize(1500, 881); // dimensioni finestra 

        inizPannelloPrincipale(); // Inizializza il pannello principale
        inizLabels(); // Inizializza le etichette (JLabel)
        initializeLetterButtons(); // Inizializza i bottoni delle lettere
        iniziaNuovaPartita(); // Avvia una nuova partita

        add(mainPanel); // Aggiunge il pannello principale alla finestra (frame)

        setVisible(true); // Rende la finestra visibile
        setResizable(false); // Disabilitato il ridimensionamento della finestra
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Chiude il programma quando si chiude la finestra di gioco
    }

    // Inizializza il pannello principale della finestra
    private void inizPannelloPrincipale() {
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g); // Chiama il metodo paintComponent della classe padre per il disegno predefinito
                try {
                    Image immag = ImageIO.read(new File("carta.jpg")); // Legge un'immagine di sfondo da un file
                    g.drawImage(immag, 0, 0, getWidth(), getHeight(), this); // Disegna l'immagine di sfondo ridimensionata all'interno del pannello principale
                } catch (IOException e) {
                    e.printStackTrace();  // Se si verifica un'eccezione durante la lettura dell'immagine, stampa l'errore
                }
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(1500, 844); // Imposta le dimensioni preferite del pannello
            }
        };
                
        mainPanel.setLayout(new GridLayout(6, 2)); // Imposta il layout del pannello principale su un layout grid con 6 righe e 2 colonne
        mainPanel.setBounds(0, 0, 1500, 844); // Imposta le dimensioni e la posizione del pannello
    }

    // Inizializza le etichette e aggiunge le etichette e i pannelli "secondari" al pannello principale
    private void inizLabels() {
        p1 = new JPanel();
        p1.setOpaque(false); // pannello impostato per essere trasparente
        p1.setLayout(new GridLayout(1, 2));
        l4 = new JLabel("Remaining guesses:");
        l4.setForeground(new java.awt.Color(79, 130, 73)); // imposta il colore del testo all'interno del componente
        l4.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        p1.add(l4);
        mainPanel.add(p1);

        p2 = new JPanel();
        p2.setOpaque(false);
        p2.setLayout(new GridLayout(1, 2));
        l2 = new JLabel("Wins: 0");
        l2.setForeground(new java.awt.Color(181, 169, 76));
        l2.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        p2.add(l2);
        mainPanel.add(p2);

        t1 = new JTextField();
        t1.addActionListener(this);

        p3 = new JPanel();
        p6 = new JPanel();
        p3.setOpaque(false);
        p3.setLayout(new GridLayout(1, 2));
        p6.setOpaque(false);
        p6.setLayout(null);
        l1 = new JLabel("Word:");
        l1.setForeground(new java.awt.Color(76, 81, 181));
        l1.setHorizontalAlignment(SwingConstants.CENTER);
        l1.setFont(new Font("Comic Sans MS", Font.BOLD, 60));
        l5 = new JLabel("Guess the full word: ");
        l5.setForeground(new java.awt.Color(167, 75, 184));
        l5.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        l3 = new JLabel("Loses: 0");
        l3.setForeground(new java.awt.Color(163, 70, 70));
        l3.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        l3.setBounds(0, 10, 200, 100);
        l5.setBounds(890, 10, 1000, 100);
        t1.setBounds(1200, 50, 200, 30);
        p6.add(l3);
        p6.add(l5);
        p6.add(t1);
        p3.add(l1);
        mainPanel.add(p6);
        mainPanel.add(p3);
    }

    // Inizializza i bottoni delle lettere
    private void initializeLetterButtons() {
        p4 = new JPanel();
        p4.setOpaque(false);
        p4.setLayout(new GridLayout(1, 13));

        p5 = new JPanel();
        p5.setOpaque(false);
        p5.setLayout(new GridLayout(1, 13));

        letterButtons = new JButton[26]; // array di pulsanti (un pulsante per ogni lettera)

        for (char c = 'A'; c <= 'Z'; c++) {  // ogni iterazione viene creato un nuovo JButton 
            JButton pulsante = new JButton(String.valueOf(c));

            pulsante.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JButton pulsanteCliccato = (JButton) e.getSource();
                    pulsanteCliccato.setEnabled(false);
                    controllaLettera(pulsanteCliccato.getText().charAt(0));
                }
            });

            if (c <= 'M') {           // prima metà dei pulsanti (fino alla m) nel pannello p4
                p4.add(pulsante); // seconda metà dei pulsanti nel pannello p5
            } else {
                p5.add(pulsante);
            }

            letterButtons[c - 'A'] = pulsante; // Memorizza il pulsante corrente nell'array letterButtons
            // L'indice dell'array è calcolato sottraendo 'A' dal carattere corrente, 
            // ottenendo così un indice compreso tra 0 e 25
            // Questo indice corrisponde alla posizione della lettera nell'alfabeto
        }

        mainPanel.add(p4); // aggiunta pannello p4 al pannello principale
        mainPanel.add(p5); // aggiunta pannello p5 al pannello principale
    }

    // Questo metodo avvia una nuova partita del gioco
    // Sceglie una parola segreta da un file, nasconde la parola, imposta il numero di tentativi rimanenti a 7,
    // aggiorna il punteggio visibile nell'interfaccia, abilita i pulsanti delle lettere e reimposta il colore dei pulsanti
    private void iniziaNuovaPartita() {
        parolaSegreta = scegliParolaDaFile(); // Sceglie la parola "segreta" da indovinare da un file
        parolaNascosta = nascondiParola(parolaSegreta); // Nasconde la parola segreta
        tentativiRimanenti = 7; // Imposta il numero di tentativi rimanenti a 7
        aggiornaPunteggio(); // Aggiorna il punteggio visibile nell'interfaccia
        abilitaDisabilitaBottoni(true); // Abilita i pulsanti delle lettere
        resettaColoriPulsanti(); // Reimposta il colore dei pulsanti
    }

    private String scegliParolaDaFile() {  // metodo che sceglie la parola "segreta" da indovinare da un file
        String[] parole = leggiParoleDaFile();
        if (parole.length == 0) {
            throw new RuntimeException("Errore: nessuna parola trovata nel file");
        }
        return parole[(int) (Math.random() * parole.length)];
    }

// Questo metodo legge le parole da un file e le restituisce come un array di stringhe
    private String[] leggiParoleDaFile() {
        String[] parole; // Dichiarazione dell'array di stringhe per memorizzare le parole lette
        try (BufferedReader br = new BufferedReader(new FileReader("Indovinare.csv"))) { // Apre il file "Indovinare.csv" per la lettura utilizzando un BufferedReader
            String line; // Dichiarazione di una variabile di tipo stringa per memorizzare una riga del file
            StringBuilder sb = new StringBuilder(); // Crea un oggetto StringBuilder per memorizzare le parole lette dal file
            while ((line = br.readLine()) != null) { // Legge una riga alla volta fino alla fine del file
                sb.append(line); // Aggiunge la riga al StringBuilder
                sb.append(","); // Aggiunge una virgola per separare le parole
            }
            parole = sb.toString().split(","); // Converte il contenuto del StringBuilder in una stringa e la divide in un array di stringhe utilizzando la virgola come delimitatore
        } catch (IOException e) { // Gestisce eventuali eccezioni di input/output
            e.printStackTrace(); // Stampa l'errore nella console
            parole = new String[0]; // Se si verifica un'eccezione, viene assegnato un array vuoto di stringhe
        }
        return parole; // Restituisce l'array di stringhe contenente le parole lette dal file
    }

    // Metodo per nascondere una parola sostituendo ogni carattere con un trattino
    private char[] nascondiParola(String parola) {
        char[] nascosta = new char[parola.length()]; // Crea un array di caratteri della stessa lunghezza della parola
        for (int i = 0; i < parola.length(); i++) { // Cicla attraverso ogni carattere della parola
            nascosta[i] = '-'; // Sostituisce il carattere corrente con un trattino
        }
        return nascosta; // Restituisce l'array di caratteri con la parola nascosta
    }

    // Metodo per controllare se la lettera inserita dall'utente è presente nella parola segreta e aggiornare di conseguenza il gioco
    private void controllaLettera(char lettera) {
        boolean letteraCorretta = false; // Variabile booleana che indica se la lettera inserita è corretta
        for (int i = 0; i < parolaSegreta.length(); i++) { // Ciclo attraverso ogni carattere della parola segreta
            if (Character.toUpperCase(parolaSegreta.charAt(i)) == Character.toUpperCase(lettera)) { // Controlla se il carattere corrente della parola segreta corrisponde alla lettera inserita dall'utente (ignorando maiuscole/minuscole)
                parolaNascosta[i] = parolaSegreta.charAt(i); // Se la lettera è corretta, aggiorna la parola nascosta sostituendo il carattere corrispondente
                letteraCorretta = true; // Imposta la variabile booleana a true per indicare che la lettera è stata trovata nella parola segreta
            }
        }

        // Aggiorna il numero di tentativi rimanenti solo se la lettera non è corretta
        if (!letteraCorretta) {
            tentativiRimanenti--; // Diminuisce il numero di tentativi rimanenti
            if (tentativiRimanenti == 0) { // Se non ci sono più tentativi rimasti, il giocatore ha perso
                GameOver(false); // Chiama il metodo GameOver passando false come parametro per indicare una sconfitta
                return; // Termina il metodo dopo aver gestito la fine del gioco
            }
        }

        // Imposta il colore del pulsante in base alla correttezza della lettera
        for (JButton button : letterButtons) { // Cicla attraverso ogni pulsante delle lettere
            if (button.getText().charAt(0) == lettera) { // Se il testo del pulsante corrisponde alla lettera inserita dall'utente
                if (letteraCorretta) {
                    button.setBackground(new java.awt.Color(79, 130, 73)); // Imposta il colore del pulsante a verde se la lettera è corretta
                } else {
                    button.setBackground(new java.awt.Color(163, 70, 70)); // Imposta il colore del pulsante a rosso se la lettera è sbagliata
                }
                button.setEnabled(false); // Disabilita il pulsante dopo aver selezionato la lettera
                break; // Esci dal ciclo for dopo aver trovato il pulsante corrispondente
            }
        }

        // Aggiorna l'etichetta Word dopo aver controllato la lettera
        aggiornaPunteggio(); // Chiama il metodo per aggiornare il punteggio nell'interfaccia grafica

        // Controlla il completamento della parola solo se ci sono ancora tentativi rimanenti
        if (tentativiRimanenti > 0 && parolaIndovinata()) { // Se la parola è stata indovinata e ci sono ancora tentativi rimanenti
            GameOver(true); // Chiama il metodo GameOver passando true come parametro per indicare una vittoria
        }
    }

    // Metodo per aggiornare il punteggio visualizzato nell'interfaccia grafica
    private void aggiornaPunteggio() {
        StringBuilder parolaVisualizzata = new StringBuilder(); // Crea un nuovo oggetto StringBuilder per memorizzare la parola nascosta visualizzata
        for (char c : parolaNascosta) { // Cicla attraverso ogni carattere della parola nascosta
            parolaVisualizzata.append(c).append(" "); // Aggiunge il carattere seguito da uno spazio al StringBuilder
        }
        l1.setText("Word: " + parolaVisualizzata.toString().trim()); // Imposta il testo dell'etichetta l1 con la parola nascosta visualizzata
        l4.setText("Remaining guesses: " + tentativiRimanenti); // Imposta il testo dell'etichetta l4 con il numero di tentativi rimanenti
    }

    // Metodo per gestire la fine del gioco
    private void GameOver(boolean vittoria) {
        if (vittoria) { // Se il giocatore ha vinto
            vittorie++; // Incrementa il contatore delle vittorie
            l2.setText("Wins: " + vittorie); // Aggiorna il testo dell'etichetta l2 con il numero di vittorie
        } else { // Se il giocatore ha perso
            sconfitte++; // Incrementa il contatore delle sconfitte
            l3.setText("Loses: " + sconfitte); // Aggiorna il testo dell'etichetta l3 con il numero di sconfitte
        }
        abilitaDisabilitaBottoni(false); // Disabilita i pulsanti delle lettere
        String message;
        if (vittoria) { // Se il giocatore ha vinto
            message = "Hai vinto!"; // Imposta il messaggio di vittoria
        } else { // Se il giocatore ha perso.
            message = "Hai perso. La parola era: " + parolaSegreta; // Imposta il messaggio di sconfitta con la parola segreta
        }
        JOptionPane.showMessageDialog(this, message); // Mostra un messaggio di dialogo con il messaggio appropriato
        iniziaNuovaPartita(); // Avvia una nuova partita
    }

    // Metodo per abilitare o disabilitare tutti i pulsanti delle lettere
    private void abilitaDisabilitaBottoni(boolean abilita) {
        for (JButton button : letterButtons) { // Cicla attraverso ogni pulsante delle lettere
            button.setEnabled(abilita); // Imposta lo stato di abilitazione del pulsant
        }
    }

// Metodo per verificare se tutte le lettere della parola sono state indovinate
    private boolean parolaIndovinata() {
        for (char c : parolaNascosta) { // Cicla attraverso ogni carattere della parola nascosta
            if (c == '-') {
                return false; // Se c'è almeno un trattino nella parola nascosta, significa che non tutte le lettere sono state indovinate
            }
        }
        return true; // Se non ci sono trattini nella parola nascosta, tutte le lettere sono state indovinate
    }

// Metodo per reimpostare il colore predefinito di tutti i pulsanti delle lettere
    private void resettaColoriPulsanti() {
        for (JButton button : letterButtons) { // Cicla attraverso ogni pulsante delle lettere
            button.setBackground(UIManager.getColor("Button.background")); // Reimposta il colore predefinito del pulsante
        }
    }

// Gestore dell'evento quando viene premuto il tasto Invio nel campo di testo
    @Override
    public void actionPerformed(ActionEvent e) {
        String parolaInserita = t1.getText().toUpperCase(); // Ottiene la parola inserita dall'utente in maiuscolo
        if (parolaInserita.equals(parolaSegreta.toUpperCase())) { // Se la parola inserita corrisponde alla parola segreta
            // Indovinato! Termina il gioco come una vittoria
            GameOver(true);
        } else {
            // Parola errata, diminuisce il numero di tentativi rimanenti
            tentativiRimanenti--;
            aggiornaPunteggio(); // Aggiorna il punteggio visibile nell'interfaccia grafica
            if (tentativiRimanenti <= 0) {
                // Nessun tentativo rimasto, termina il gioco come una sconfitta
                GameOver(false);
            }
        }
        // Pulisce il campo di testo dopo aver inserito la parola
        t1.setText("");
    }

// Metodo principale per avviare l'applicazione
    public static void main(String[] args) {
        ImpiccatoGrafico g = new ImpiccatoGrafico("Impiccato"); // Crea un'istanza della classe ImpiccatoGrafico con il titolo "Impiccato"
    }
}
