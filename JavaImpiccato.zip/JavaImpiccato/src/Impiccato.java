/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author simat
 */
// Import delle classi necessarie per la lettura da file e l'input da tastiera
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

// Definizione della classe principale Impiccato
public class Impiccato {

    // Costante per il percorso del file contenente le parole da indovinare
    private static final String FILE_PAROLE = "Indovinare.csv";

    // Metodo principale main, punto di ingresso dell'applicazione
    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in); // Creazione di un oggetto Scanner per l'input da tastiera

        // Inizializzazione della parola segreta, della parola nascosta e dei tentativi rimasti
        String parSegreta = scegliParolaDaFile();
        char[] parNascosta = nascondiParola(parSegreta);
        int tentativiRimasti = 7;

        // Output delle istruzioni all'utente
        System.out.println("Hai 7 tentativi per indovinare la parola.");
        System.out.println("La parola contiene " + parSegreta.length() + " lettere.");

        // Ciclo principale del gioco
        while (tentativiRimasti > 0 && !parIndov(parNascosta)) {
            // Output delle informazioni attuali
            System.out.println("Parola: " + String.valueOf(parNascosta));
            System.out.println("Tentativi rimasti: " + tentativiRimasti);
            System.out.println("Inserisci la parola o lettera: ");
            String tentativo = inp.next().toLowerCase();

            // Verifica se l'input dell'utente è costituito da una singola lettera
            if (tentativo.length() == 1) {
                // Estrae la lettera dall'input dell'utente
                char lettera = tentativo.charAt(0);
                // Controlla se la lettera indovinata è presente nella parola segreta
                if (indovinaLettera(parSegreta, parNascosta, lettera)) {
                    // Stampa un messaggio di conferma se la lettera è corretta
                    System.out.println("Bravo! La lettera è corretta.");
                } else {
                    // Decrementa il numero di tentativi rimasti se la lettera non è corretta
                    tentativiRimasti--;
                    // Stampa un messaggio se la lettera non è presente nella parola segreta
                    System.out.println("Peccato! La lettera non è presente nella parola.");
                }
            } else if (tentativo.length() == parSegreta.length()) { // Verifica se l'input dell'utente è della stessa lunghezza della parola segreta
                // Se la lunghezza dell'input corrisponde a quella della parola segreta,
                // controlla se l'input coincide esattamente con la parola segreta
                if (tentativo.equals(parSegreta)) {
                    // Stampa un messaggio di congratulazioni se l'input corrisponde alla parola segreta
                    System.out.println("Complimenti! Hai indovinato la parola: " + parSegreta);
                    return;
                } else {
                    // Altrimenti, decrementa il numero di tentativi rimasti e avvisa che la parola inserita non è corretta
                    System.out.println("Mi dispiace, la parola inserita non è corretta.");
                    tentativiRimasti--;
                }
            } else {
                // Se l'input non è né una singola lettera né una parola della stessa lunghezza della parola segreta,
                // segnala un errore e chiede all'utente di inserire correttamente una singola lettera o l'intera parola
                System.out.println("Errore, inserisci una sola lettera o la parola intera.");
            }

            // Verifica se il giocatore ha indovinato la parola o ha esaurito i tentativi
            if (parIndov(parNascosta)) {
                System.out.println("Complimenti! Hai indovinato la parola: " + parSegreta);
            } else {
                System.out.println("Mi dispiace, hai esaurito i tentativi. La parola era: " + parSegreta);
            }
        }
    }

    // Metodo per scegliere casualmente una parola dal file
    private static String scegliParolaDaFile() {
        // Ottiene tutte le parole dal file
        String[] parole = leggiParoleDaFile();
        // Controlla se non ci sono parole nel file
        if (parole.length == 0) {
            // Se non ci sono parole, stampa un messaggio di errore e termina il programma
            System.out.println("Errore: nessuna parola trovata nel file.");
            System.exit(1);
        }
        // Restituisce una parola casuale dall'array delle parole lette dal file
        return parole[(int) (Math.random() * parole.length)];
    }

    // Metodo per leggere le parole da un file
    private static String[] leggiParoleDaFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PAROLE))) {
            String line;
            StringBuilder sb = new StringBuilder();
            // Legge ogni riga dal file e le aggiunge alla stringa StringBuilder,
            // separando le parole con una virgola
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append(",");
            }
            // Converte la stringa completa in un array di stringhe dividendo le parole
            // utilizzando la virgola come delimitatore e restituisce l'array risultante
            return sb.toString().split(",");
        } catch (IOException e) {
            // Se si verifica un'eccezione di tipo IOException durante la lettura del file,
            // stampa la traccia dello stack dell'eccezione e restituisce un array vuoto
            e.printStackTrace();
            return new String[0];
        }
    }

    // Metodo per nascondere la parola sostituendo ogni carattere con un asterisco
    private static char[] nascondiParola(String parola) {
        // Crea un array di caratteri della stessa lunghezza della parola,
        // inizializzandolo con asterischi
        char[] nascosta = new char[parola.length()];
        for (int i = 0; i < parola.length(); i++) {
            nascosta[i] = '*';
        }
        // Restituisce l'array con la parola nascosta
        return nascosta;
    }

// Metodo per indovinare una lettera nella parola nascosta
    private static boolean indovinaLettera(String parola, char[] parolaNascosta, char lettera) {
        boolean trovato = false;
        // Scorre ogni carattere della parola e se la lettera corrisponde, la sostituisce
        // nella parola nascosta e imposta trovato a true
        for (int i = 0; i < parola.length(); i++) {
            if (parola.charAt(i) == lettera) {
                parolaNascosta[i] = lettera;
                trovato = true;
            }
        }
        // Restituisce true se la lettera è stata trovata, altrimenti false
        return trovato;
    }

    // Metodo per verificare se la parola è stata completamente indovinata
    private static boolean parIndov(char[] parolaNascosta) {
        // Scorre ogni carattere della parola nascosta
        for (char c : parolaNascosta) {
            // Se trova anche solo un asterisco, la parola non è stata completamente indovinata, quindi restituisce false
            if (c == '*') {
                return false;
            }
        }
        // Se non ci sono asterischi nella parola nascosta, significa che è stata completamente indovinata, quindi restituisce true
        return true;
    }
}